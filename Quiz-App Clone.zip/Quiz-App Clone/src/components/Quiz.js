import React, { useState } from 'react';
import quizData from '../data/quizData';
import ResultsPage from './ResultsPage';
import '../Style.css';

function Quiz() {
  const [userName, setUserName] = useState('');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);

  const handleNameInputChange = (event) => {
    setUserName(event.target.value);
  };

  const handleStartQuiz = () => {
    if (userName.trim() !== '') {
      setCurrentQuestion(0);
      setScore(0);
      setShowScore(false);
      setQuizStarted(true);
    } else {
      alert('Please enter your name to start the quiz.');
    }
  };

  const handleAnswerOptionClick = (selectedOptionIndex) => {
    const isCorrect = selectedOptionIndex === quizData[currentQuestion].Answer - 1;

    if (isCorrect) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < quizData.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowScore(true);
    }
  };

  const handleFinishGame = () => {
    setShowScore(true);
  };

  const getOptionLabel = (index) => {
    // Convert index to corresponding option label (A, B, C, D)
    return String.fromCharCode(65 + index);
  };

  return (
    <div className='User'>
      {!quizStarted ? (
        <div>
          <label htmlFor="userName">Enter your name:</label>
          <input
            type="text"
            id="userName"
            value={userName}
            onChange={handleNameInputChange}
            disabled={quizStarted}
          />
          <button onClick={handleStartQuiz} disabled={quizStarted}>
            Start Quiz
          </button>
        </div>
      ) : (
        <>
          <h1>Welcome, {userName}!</h1>
          {!showScore ? (
            <>
              <div className='question-section'>
                <div className='question-count'>
                  <span>Question {currentQuestion + 1}</span>/{quizData.length}
                </div>
                <div className='question-text'>{quizData[currentQuestion].Question}</div>
              </div>
              <div className='answer-section'>
                {quizData[currentQuestion].Options.map((option, index) => (
                  <button key={index} onClick={() => handleAnswerOptionClick(index)}>
                    {getOptionLabel(index)}. {option}
                  </button>
                ))}
              </div>
              <button onClick={handleFinishGame}>Finish Game</button>
            </>
          ) : (
            <ResultsPage userName={userName} score={score} />
          )}
        </>
      )}
    </div>
  );
}

export default Quiz;
