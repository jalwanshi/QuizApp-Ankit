import React, { useEffect, useMemo } from 'react';
import quizData from '../data/quizData';

function ResultsPage({ userName, score }) {
  // Memoize the existingPlayers array
  const existingPlayers = useMemo(() => {
    return JSON.parse(localStorage.getItem('quizPlayers')) || [];
  }, []);

  // Memoize the updatedPlayers array
  const updatedPlayers = useMemo(() => {
    return [...existingPlayers, { name: userName, score: score }];
  }, [existingPlayers, userName, score]);

  // Sort players by score in descending order
  const sortedPlayers = [...updatedPlayers].sort((a, b) => b.score - a.score);

  // Update local storage with updated player data
  useEffect(() => {
    localStorage.setItem('quizPlayers', JSON.stringify(updatedPlayers));
  }, [updatedPlayers]);

  return (
    <div>
      <h2>Quiz Score</h2>
      <p>{userName}, you scored {score} out of {quizData.length}</p>
      
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {/* Render sorted players */}
          {sortedPlayers.map((player, index) => (
            <tr key={index}>
              <td>{player.name}</td>
              <td>{player.score}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Display the highest scorer separately */}
      {sortedPlayers.length > 0 && (
        <div>
          <h3>Highest Scorer:</h3>
          <p>{sortedPlayers[0].name} - {sortedPlayers[0].score}</p>
        </div>
      )}
    </div>
  );
}

export default ResultsPage;
