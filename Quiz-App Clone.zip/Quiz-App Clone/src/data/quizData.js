var quizData = [
    {
      Question: "What does CPU stand for?",
      Options: ["Central Processing Unit", "Computer Personal Unit", "Central Processor Unit", "Central Personal Unit"],
      Answer: 1,
    },
    {
      Question: "Which one is not a programming language?",
      Options: ["Java", "Python", "HTML", "CSS"],
      Answer: 3,
    },
    {
      Question: "What is the full form of HTML?",
      Options: ["Hyper Text Markup Language", "Hyperlinks and Text Markup Language", "Home Tool Markup Language", "Hyperlink Markup Language"],
      Answer: 1,
    },
    {
      Question: "Which programming language is also known as the 'Scripting Language for Web'?",
      Options: ["Java", "Python", "PHP", "JavaScript"],
      Answer: 4,
    },
    {
      Question: "What is the function of RAM in a computer?",
      Options: ["Random Access Memory", "Read And Modify", "Read Access Memory", "Randomly Access Memory"],
      Answer: 1,
    },
    {
      Question: "What is the file extension for a Java source code file?",
      Options: [".java", ".js", ".html", ".css"],
      Answer: 1,
    },
    {
      Question: "Which company developed the JavaScript programming language?",
      Options: ["Microsoft", "Apple", "Netscape", "Sun Microsystems"],
      Answer: 3,
    },
    {
      Question: "Which data structure uses Last In, First Out (LIFO) principle?",
      Options: ["Queue", "Stack", "Linked List", "Tree"],
      Answer: 2,
    },
    {
      Question: "What is the default port number for HTTP protocol?",
      Options: ["80", "443", "8080", "21"],
      Answer: 1,
    },
    {
      Question: "What is the main purpose of a firewall?",
      Options: ["To block unauthorized access", "To store data", "To process data", "To enhance internet speed"],
      Answer: 1,
    },
    {
      Question: "Which programming language is widely used for artificial intelligence?",
      Options: ["Java", "Python", "C++", "Ruby"],
      Answer: 2,
    },
    {
      Question: "What is the full form of CSS?",
      Options: ["Cascading Style Sheets", "Computer Style Sheets", "Creative Style Sheets", "Colorful Style Sheets"],
      Answer: 1,
    },
    {
      Question: "What is the binary equivalent of decimal number 10?",
      Options: ["1010", "1100", "1111", "1001"],
      Answer: 1,
    },
    {
      Question: "Which command is used to print the current working directory in Unix/Linux?",
      Options: ["pwd", "ls", "cd", "mkdir"],
      Answer: 1,
    },
    {
      Question: "What is the full form of URL?",
      Options: ["Uniform Resource Locator", "Uniform Resource Link", "Unified Resource Locator", "Unified Resource Link"],
      Answer: 1,
    },
    {
      Question: "Which programming language is primarily used for developing Android apps?",
      Options: ["Java", "Python", "C++", "JavaScript"],
      Answer: 1,
    },
    {
      Question: "What is the function of a compiler?",
      Options: ["To convert source code into machine code", "To execute the program", "To debug the program", "To format the program"],
      Answer: 1,
    },
    {
      Question: "What does LAN stand for?",
      Options: ["Local Area Network", "Long Area Network", "Large Area Network", "Logical Area Network"],
      Answer: 1,
    },
    {
      Question: "Which symbol is used to denote comments in Python?",
      Options: ["#", "//", "/* */", "!--"],
      Answer: 1,
    },
    {
      Question: "What is the full form of SQL?",
      Options: ["Structured Query Language", "Sequential Query Language", "Structured Quality Language", "Sequential Quality Language"],
      Answer: 1,
    },
    {
      Question: "What is the full form of JSON?",
      Options: ["JavaScript Object Notation", "JavaScript Oriented Notation", "JavaScript Object Namespace", "JavaScript Object Node"],
      Answer: 1,
    },
    {
      Question: "Which one is a relational database management system?",
      Options: ["MySQL", "MongoDB", "Firebase", "Redis"],
      Answer: 1,
    },
    {
      Question: "What is the full form of API?",
      Options: ["Application Programming Interface", "Advanced Program Interface", "Application Process Interface", "Advanced Programming Interface"],
      Answer: 1,
    },
    {
      Question: "What does GPU stand for?",
      Options: ["Graphics Processing Unit", "General Processing Unit", "Gaming Processing Unit", "Graphical Personal Unit"],
      Answer: 1,
    },
    {
      Question: "Which one is a front-end framework?",
      Options: ["React", "Node.js", "Express", "MongoDB"],
      Answer: 1,
    },
    {
      Question: "Which one is not a JavaScript library or framework?",
      Options: ["React", "Angular", "Vue", "JavaFX"],
      Answer: 4,
    },
    {
      Question: "What is the full form of JSON?",
      Options: ["JavaScript Object Notation", "JavaScript Oriented Notation", "JavaScript Object Namespace", "JavaScript Object Node"],
      Answer: 1,
    },
    {
      Question: "Which one is a NoSQL database?",
      Options: ["MySQL", "MongoDB", "PostgreSQL", "Oracle"],
      Answer: 2,
    },
    {
      Question: "Which programming language is commonly used for data analysis and machine learning?",
      Options: ["Java", "Python", "C++", "Ruby"],
      Answer: 2,
    },
  ];
  
  export default quizData;
  