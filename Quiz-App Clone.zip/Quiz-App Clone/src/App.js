import React from 'react';
import Quiz from './components/Quiz'; 
import './Style.css'
function App() {
  return (
    <div className="App">
      <h1>Welcome to the Quiz App Created by Ankit!</h1>
      <Quiz /> 
    </div>
  );
}

export default App;
